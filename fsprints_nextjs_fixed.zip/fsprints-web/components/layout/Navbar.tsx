'use client';
import { useState } from 'react';
import Link from 'next/link';
import { usePathname } from 'next/navigation';

const links = [
  { href: '/shop',     label: 'Shop' },
  { href: '/bulk',     label: 'Bulk Orders' },
  { href: '/services', label: 'Services' },
  { href: '/about',    label: 'About' },
];

export default function Navbar() {
  const [open, setOpen] = useState(false);
  const path = usePathname();

  return (
    <nav style={{
      position: 'sticky', top: 0, zIndex: 100,
      background: 'var(--ink)', borderBottom: '1px solid rgba(255,255,255,0.08)',
    }}>
      <div className="container" style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', height: '64px' }}>
        {/* Logo */}
        <Link href="/" style={{ display: 'flex', alignItems: 'center', gap: '0.5rem' }}>
          <span style={{ fontFamily: 'var(--font-display)', fontSize: '1.4rem', color: 'var(--gold)', fontWeight: 700 }}>FS</span>
          <span style={{ color: 'var(--white)', fontWeight: 500, letterSpacing: '0.05em', fontSize: '0.95rem' }}>PRINTS</span>
        </Link>

        {/* Desktop links */}
        <div className="hide-mobile" style={{ display: 'flex', gap: '2rem', alignItems: 'center' }}>
          {links.map(l => (
            <Link key={l.href} href={l.href} style={{
              color: path === l.href ? 'var(--gold)' : 'rgba(255,255,255,0.8)',
              fontWeight: path === l.href ? 600 : 400,
              fontSize: '0.9rem',
              transition: 'color 0.15s',
            }}>{l.label}</Link>
          ))}
          <Link href="/shop" className="btn btn-primary" style={{ padding: '0.5rem 1.25rem', fontSize: '0.875rem' }}>
            Order Now
          </Link>
        </div>

        {/* Mobile hamburger */}
        <button onClick={() => setOpen(!open)} style={{ background: 'none', border: 'none', color: 'var(--white)', fontSize: '1.5rem', display: 'none' }}
          className="show-mobile">☰</button>
      </div>

      {/* Mobile menu */}
      {open && (
        <div style={{ background: 'var(--ink)', borderTop: '1px solid rgba(255,255,255,0.1)', padding: '1rem 1.5rem', display: 'flex', flexDirection: 'column', gap: '1rem' }}>
          {links.map(l => (
            <Link key={l.href} href={l.href} onClick={() => setOpen(false)}
              style={{ color: 'rgba(255,255,255,0.85)', fontWeight: 500 }}>{l.label}</Link>
          ))}
        </div>
      )}

      <style>{`
        @media (max-width: 768px) {
          .hide-mobile { display: none !important; }
          .show-mobile { display: block !important; }
        }
      `}</style>
    </nav>
  );
}

import Link from 'next/link';

export default function Footer() {
  return (
    <footer style={{ background: 'var(--ink)', color: 'rgba(255,255,255,0.7)', padding: '3rem 0 1.5rem' }}>
      <div className="container">
        <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(200px, 1fr))', gap: '2rem', marginBottom: '2.5rem' }}>
          <div>
            <div style={{ fontFamily: 'var(--font-display)', fontSize: '1.5rem', color: 'var(--gold)', marginBottom: '0.75rem' }}>FS Prints</div>
            <p style={{ fontSize: '0.875rem', lineHeight: 1.7 }}>Stationery retail &amp; spiral notebook manufacturing. Serving Karachi since 2023.</p>
          </div>
          <div>
            <div style={{ color: 'var(--white)', fontWeight: 600, marginBottom: '0.75rem', fontSize: '0.875rem', letterSpacing: '0.08em', textTransform: 'uppercase' }}>Quick Links</div>
            {[['/', 'Home'], ['/shop', 'Shop'], ['/bulk', 'Bulk Orders'], ['/services', 'Services'], ['/about', 'About']].map(([href, label]) => (
              <Link key={href} href={href} className="footer-link"
                style={{ display: 'block', fontSize: '0.875rem', marginBottom: '0.4rem', color: 'rgba(255,255,255,0.7)' }}>
                {label}
              </Link>
            ))}
          </div>
          <div>
            <div style={{ color: 'var(--white)', fontWeight: 600, marginBottom: '0.75rem', fontSize: '0.875rem', letterSpacing: '0.08em', textTransform: 'uppercase' }}>Contact</div>
            <p style={{ fontSize: '0.875rem', lineHeight: 1.9 }}>
              📍 Karachi, Pakistan<br />
              📞 <a href="tel:+92" style={{ color: 'inherit' }}>+92 XXX XXXXXXX</a><br />
              ✉️ <a href="mailto:info@fsprints.pk" style={{ color: 'inherit' }}>info@fsprints.pk</a><br />
              💬 <a href="https://wa.me/92" target="_blank" rel="noreferrer" style={{ color: 'var(--gold)' }}>WhatsApp Us</a>
            </p>
          </div>
        </div>
        <div style={{ borderTop: '1px solid rgba(255,255,255,0.1)', paddingTop: '1.25rem', display: 'flex', justifyContent: 'space-between', alignItems: 'center', flexWrap: 'wrap', gap: '0.5rem', fontSize: '0.8rem' }}>
          <span>© {new Date().getFullYear()} FS Prints. All rights reserved.</span>
          <span>Cash on Delivery · Bank Transfer · Karachi Delivery</span>
        </div>
      </div>
      <style>{`.footer-link:hover { color: var(--gold) !important; }`}</style>
    </footer>
  );
}

'use client';
import { useState } from 'react';
import { submitQuote } from '@/lib/api';

const offerings = [
  { icon: '📒', title: 'Bulk Spiral Notebooks', desc: 'Custom-manufactured A4/A5 spiral notebooks with your branding. MOQ: 50 units. Delivered across Pakistan.' },
  { icon: '🖨️', title: 'Bulk Printing Orders', desc: 'High-volume visiting cards, brochures, flyers, and catalogues. Competitive rates for repeat corporate clients.' },
  { icon: '📋', title: 'Stationery Supply Contracts', desc: 'Monthly stationery supply for offices and institutions. Fixed pricing, reliable delivery, single invoice.' },
  { icon: '🎪', title: 'Event & Exhibition Printing', desc: 'Banners, standees, flex printing, and branded handouts for events, exhibitions, and product launches.' },
];

export default function BulkPage() {
  const [form, setForm] = useState({ type:'bulk_notebooks', name:'', contact_person:'', phone:'', email:'', city:'Karachi', quantity:'', timeline:'', details:'' });
  const [status, setStatus] = useState<'idle'|'loading'|'success'|'error'>('idle');
  const [ref, setRef] = useState('');

  const handleSubmit = async () => {
    if (!form.name || !form.phone || !form.details) return;
    setStatus('loading');
    try {
      const res = await submitQuote({ ...form, quantity: form.quantity ? parseInt(form.quantity) : undefined });
      setRef(res.data.quote_ref);
      setStatus('success');
    } catch { setStatus('error'); }
  };

  return (
    <div>
      {/* Header */}
      <section style={{ background: 'var(--ink)', padding: '4rem 0 3rem' }}>
        <div className="container">
          <span style={{ fontSize: '0.75rem', fontWeight: 600, letterSpacing: '0.1em', textTransform: 'uppercase', color: 'var(--gold)' }}>Bulk & Corporate</span>
          <h1 className="display" style={{ color: 'var(--white)', marginTop: '0.5rem', marginBottom: '1rem' }}>Built for Businesses</h1>
          <p style={{ color: 'rgba(255,255,255,0.7)', maxWidth: '520px', lineHeight: 1.8 }}>
            From 50 branded notebooks to recurring stationery contracts — we manufacture and supply directly. No middlemen.
          </p>
        </div>
      </section>

      {/* Offerings */}
      <section className="section" style={{ background: 'var(--ivory)' }}>
        <div className="container">
          <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(260px, 1fr))', gap: '1.5rem' }}>
            {offerings.map(o => (
              <div key={o.title} className="card" style={{ padding: '1.75rem' }}>
                <div style={{ fontSize: '2.25rem', marginBottom: '0.75rem' }}>{o.icon}</div>
                <h3 style={{ marginBottom: '0.5rem', fontFamily: 'var(--font-display)' }}>{o.title}</h3>
                <p style={{ color: 'var(--muted)', fontSize: '0.9rem', lineHeight: 1.7 }}>{o.desc}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Quote Form */}
      <section className="section" style={{ background: 'var(--white)' }}>
        <div className="container">
          <div style={{ maxWidth: '640px', margin: '0 auto' }}>
            <span style={{ fontSize: '0.75rem', fontWeight: 600, letterSpacing: '0.1em', textTransform: 'uppercase', color: 'var(--gold)' }}>Get a Quote</span>
            <h2 className="display" style={{ marginTop: '0.5rem', marginBottom: '0.5rem' }}>Tell us what you need</h2>
            <p style={{ color: 'var(--muted)', marginBottom: '2.5rem' }}>We respond within 24 hours with pricing and lead time.</p>

            {status === 'success' ? (
              <div style={{ background: 'var(--ivory)', border: '1px solid var(--border)', borderRadius: 'var(--radius-lg)', padding: '2.5rem', textAlign: 'center' }}>
                <div style={{ fontSize: '3rem', marginBottom: '1rem' }}>✅</div>
                <h3 className="display" style={{ marginBottom: '0.5rem' }}>Inquiry Received!</h3>
                <p style={{ color: 'var(--muted)', marginBottom: '0.5rem' }}>Your reference number:</p>
                <div style={{ fontFamily: 'var(--font-display)', fontSize: '1.4rem', color: 'var(--gold)', marginBottom: '1rem' }}>{ref}</div>
                <p style={{ color: 'var(--muted)', fontSize: '0.875rem' }}>We'll WhatsApp or email you within 24 hours.</p>
              </div>
            ) : (
              <div style={{ display: 'flex', flexDirection: 'column', gap: '1.25rem' }}>
                <div className="form-group">
                  <label className="form-label">What do you need?</label>
                  <select className="form-select" value={form.type} onChange={e => setForm({...form, type: e.target.value})}>
                    <option value="bulk_notebooks">Bulk Spiral Notebooks</option>
                    <option value="bulk_printing">Bulk Printing</option>
                    <option value="stationery_contract">Stationery Supply Contract</option>
                    <option value="event_printing">Event / Exhibition Printing</option>
                    <option value="services">Other Service</option>
                  </select>
                </div>
                <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '1rem' }}>
                  <div className="form-group">
                    <label className="form-label">Company / Business Name *</label>
                    <input className="form-input" value={form.name} onChange={e => setForm({...form, name: e.target.value})} placeholder="Ahmed Enterprises" />
                  </div>
                  <div className="form-group">
                    <label className="form-label">Contact Person</label>
                    <input className="form-input" value={form.contact_person} onChange={e => setForm({...form, contact_person: e.target.value})} placeholder="Ahmed Khan" />
                  </div>
                </div>
                <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '1rem' }}>
                  <div className="form-group">
                    <label className="form-label">Phone *</label>
                    <input className="form-input" value={form.phone} onChange={e => setForm({...form, phone: e.target.value})} placeholder="03XX XXXXXXX" />
                  </div>
                  <div className="form-group">
                    <label className="form-label">Email</label>
                    <input className="form-input" type="email" value={form.email} onChange={e => setForm({...form, email: e.target.value})} placeholder="optional" />
                  </div>
                </div>
                <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '1rem' }}>
                  <div className="form-group">
                    <label className="form-label">Approximate Quantity</label>
                    <input className="form-input" type="number" value={form.quantity} onChange={e => setForm({...form, quantity: e.target.value})} placeholder="e.g. 500" />
                  </div>
                  <div className="form-group">
                    <label className="form-label">Timeline Needed</label>
                    <input className="form-input" value={form.timeline} onChange={e => setForm({...form, timeline: e.target.value})} placeholder="e.g. 2 weeks" />
                  </div>
                </div>
                <div className="form-group">
                  <label className="form-label">Describe your requirement *</label>
                  <textarea className="form-textarea" value={form.details} onChange={e => setForm({...form, details: e.target.value})}
                    placeholder="e.g. 500 A4 spiral notebooks, 100 pages, with our logo printed on the cover in blue..." />
                </div>
                {status === 'error' && <p style={{ color: 'var(--error)', fontSize: '0.875rem' }}>Submission failed. Please WhatsApp us directly.</p>}
                <button onClick={handleSubmit} disabled={status === 'loading' || !form.name || !form.phone || !form.details}
                  className="btn btn-primary" style={{ alignSelf: 'flex-start', padding: '0.85rem 2rem' }}>
                  {status === 'loading' ? 'Sending...' : 'Send Inquiry →'}
                </button>
              </div>
            )}
          </div>
        </div>
      </section>
    </div>
  );
}

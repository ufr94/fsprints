import Link from 'next/link';

const timeline = [
  { year: '2023', title: 'FS Prints Opens', desc: 'Started as a stationery retail shop in Karachi. Counter and vendor sales from day one.' },
  { year: '2024', title: 'Manufacturing Begins', desc: 'Introduced in-house spiral notebook manufacturing. First corporate bulk orders fulfilled.' },
  { year: '2025', title: 'Custom ERP Built', desc: 'Built a full PHP/MySQL ERP system from scratch — accounting, inventory, POS, manufacturing. No SaaS. No shortcuts.' },
  { year: '2026', title: 'Going Online', desc: 'Ecommerce store launched. Live ERP sync. Every online order posts directly into the accounting system.' },
];

export default function AboutPage() {
  return (
    <div>
      <section style={{ background: 'var(--ink)', padding: '5rem 0 4rem', position: 'relative', overflow: 'hidden' }}>
        <div style={{ position: 'absolute', inset: 0, backgroundImage: 'linear-gradient(rgba(232,160,32,0.04) 1px, transparent 1px), linear-gradient(90deg, rgba(232,160,32,0.04) 1px, transparent 1px)', backgroundSize: '40px 40px' }} />
        <div className="container" style={{ position: 'relative', maxWidth: '680px' }}>
          <span style={{ fontSize: '0.75rem', fontWeight: 600, letterSpacing: '0.1em', textTransform: 'uppercase', color: 'var(--gold)' }}>Our Story</span>
          <h1 className="display" style={{ color: 'var(--white)', marginTop: '0.5rem', marginBottom: '1.25rem' }}>
            Built from scratch.<br /><span style={{ color: 'var(--gold)' }}>In Karachi.</span>
          </h1>
          <p style={{ color: 'rgba(255,255,255,0.75)', lineHeight: 1.9, fontSize: '1.05rem' }}>
            FS Prints started as a counter stationery shop and grew into a manufacturer. No VC funding. No franchise. Just a founder who kept building — the business, the systems, and now the software.
          </p>
        </div>
      </section>

      {/* Timeline */}
      <section className="section" style={{ background: 'var(--white)' }}>
        <div className="container" style={{ maxWidth: '720px' }}>
          <h2 className="display" style={{ marginBottom: '3rem' }}>How we got here</h2>
          <div style={{ position: 'relative', paddingLeft: '2rem', borderLeft: '2px solid var(--border)' }}>
            {timeline.map((t, i) => (
              <div key={t.year} style={{ position: 'relative', marginBottom: i < timeline.length - 1 ? '2.5rem' : 0 }}>
                <div style={{
                  position: 'absolute', left: '-2.65rem', top: '0.2rem',
                  width: '20px', height: '20px', borderRadius: '50%',
                  background: 'var(--gold)', border: '3px solid var(--white)',
                  boxShadow: '0 0 0 2px var(--gold)',
                }} />
                <span style={{ fontFamily: 'var(--font-display)', fontSize: '0.9rem', color: 'var(--gold)', fontWeight: 700 }}>{t.year}</span>
                <h3 style={{ margin: '0.25rem 0 0.5rem', fontSize: '1.1rem' }}>{t.title}</h3>
                <p style={{ color: 'var(--muted)', fontSize: '0.9rem', lineHeight: 1.7 }}>{t.desc}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Values */}
      <section className="section" style={{ background: 'var(--ivory)', borderTop: '1px solid var(--border)' }}>
        <div className="container">
          <h2 className="display" style={{ marginBottom: '2.5rem', textAlign: 'center' }}>How we operate</h2>
          <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(220px, 1fr))', gap: '1.5rem' }}>
            {[
              { icon: '🏭', title: 'In-house manufacturing', desc: 'Spiral notebooks made on our own machines. No outsourcing, full quality control.' },
              { icon: '💰', title: 'No interest financing', desc: 'Business runs on Shariah-compliant Mudarabah. No riba in our books.' },
              { icon: '🔧', title: 'Built, not bought', desc: 'Our ERP system is custom-built by us. We own our own data and infrastructure.' },
              { icon: '📦', title: 'Real stock, live prices', desc: 'What you see on this website is the actual inventory in our system, in real time.' },
            ].map(v => (
              <div key={v.title} className="card" style={{ padding: '1.75rem' }}>
                <div style={{ fontSize: '2rem', marginBottom: '0.75rem' }}>{v.icon}</div>
                <h3 style={{ fontFamily: 'var(--font-display)', marginBottom: '0.5rem' }}>{v.title}</h3>
                <p style={{ color: 'var(--muted)', fontSize: '0.875rem', lineHeight: 1.7 }}>{v.desc}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* CTA */}
      <section style={{ background: 'var(--ink)', padding: '4rem 0', textAlign: 'center' }}>
        <div className="container">
          <h2 className="display" style={{ color: 'var(--white)', marginBottom: '1rem' }}>Ready to order?</h2>
          <p style={{ color: 'rgba(255,255,255,0.65)', marginBottom: '2rem' }}>Browse our live inventory or get a quote for bulk orders.</p>
          <div style={{ display: 'flex', gap: '1rem', justifyContent: 'center', flexWrap: 'wrap' }}>
            <Link href="/shop" className="btn btn-primary">Shop Retail</Link>
            <Link href="/bulk" className="btn btn-outline">Bulk Quote</Link>
          </div>
        </div>
      </section>
    </div>
  );
}

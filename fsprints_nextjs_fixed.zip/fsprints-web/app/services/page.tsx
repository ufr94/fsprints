'use client';
import { useState } from 'react';
import { submitQuote } from '@/lib/api';

const services = [
  { icon: '🖼️', title: 'Flex & Banner Printing', desc: 'Large format outdoor and indoor flex printing. Standees, backdrops, and hoarding banners.', tags: ['Outdoor', 'Indoor', 'Large Format'] },
  { icon: '🎴', title: 'Visiting Cards', desc: 'Premium business cards — matte, gloss, or spot UV finish. Standard and custom sizes.', tags: ['Business', 'Premium', 'Custom Size'] },
  { icon: '📰', title: 'Flyers & Brochures', desc: 'Single-sided, double-sided, or tri-fold brochures for marketing and product promotion.', tags: ['Marketing', 'A4', 'A5'] },
  { icon: '📁', title: 'Corporate Stationery', desc: 'Letterheads, envelopes, notepads, and folders with your brand identity.', tags: ['Brand Kit', 'Office'] },
  { icon: '🎪', title: 'Exhibition Packages', desc: 'Complete exhibition printing — banners, flyers, name badges, and branded stationery kits.', tags: ['Events', 'Exhibitions', 'Package'] },
  { icon: '📒', title: 'Custom Notebooks', desc: 'Spiral and hardcover notebooks with custom covers for corporate gifting and education.', tags: ['Corporate Gift', 'Education'] },
];

export default function ServicesPage() {
  const [form, setForm] = useState({ type:'services', name:'', phone:'', email:'', details:'' });
  const [status, setStatus] = useState<'idle'|'loading'|'success'|'error'>('idle');
  const [ref, setRef] = useState('');

  const handleSubmit = async () => {
    if (!form.name || !form.phone || !form.details) return;
    setStatus('loading');
    try {
      const res = await submitQuote(form);
      setRef(res.data.quote_ref);
      setStatus('success');
    } catch { setStatus('error'); }
  };

  return (
    <div>
      <section style={{ background: 'var(--ink)', padding: '4rem 0 3rem' }}>
        <div className="container">
          <span style={{ fontSize: '0.75rem', fontWeight: 600, letterSpacing: '0.1em', textTransform: 'uppercase', color: 'var(--gold)' }}>Print Services</span>
          <h1 className="display" style={{ color: 'var(--white)', marginTop: '0.5rem', marginBottom: '1rem' }}>We Make Your Brand Visible</h1>
          <p style={{ color: 'rgba(255,255,255,0.7)', maxWidth: '520px', lineHeight: 1.8 }}>
            From a single visiting card to a full exhibition setup — professional print production out of Karachi.
          </p>
        </div>
      </section>

      <section className="section" style={{ background: 'var(--white)' }}>
        <div className="container">
          <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(280px, 1fr))', gap: '1.5rem', marginBottom: '4rem' }}>
            {services.map(s => (
              <div key={s.title} className="card" style={{ padding: '1.75rem' }}>
                <div style={{ fontSize: '2.25rem', marginBottom: '0.75rem' }}>{s.icon}</div>
                <h3 style={{ marginBottom: '0.5rem', fontFamily: 'var(--font-display)' }}>{s.title}</h3>
                <p style={{ color: 'var(--muted)', fontSize: '0.9rem', lineHeight: 1.7, marginBottom: '1rem' }}>{s.desc}</p>
                <div style={{ display: 'flex', gap: '0.5rem', flexWrap: 'wrap' }}>
                  {s.tags.map(t => <span key={t} className="badge badge-gold">{t}</span>)}
                </div>
              </div>
            ))}
          </div>

          {/* Quick inquiry */}
          <div style={{ background: 'var(--ivory)', borderRadius: 'var(--radius-lg)', padding: '2.5rem', maxWidth: '600px', margin: '0 auto', border: '1px solid var(--border)' }}>
            <span style={{ fontSize: '0.75rem', fontWeight: 600, letterSpacing: '0.1em', textTransform: 'uppercase', color: 'var(--gold)' }}>Quick Inquiry</span>
            <h2 className="display" style={{ fontSize: '1.75rem', marginTop: '0.5rem', marginBottom: '1.5rem' }}>Get a Quote in 24 Hours</h2>

            {status === 'success' ? (
              <div style={{ textAlign: 'center', padding: '1rem 0' }}>
                <div style={{ fontSize: '2.5rem', marginBottom: '0.75rem' }}>✅</div>
                <p style={{ fontWeight: 600, marginBottom: '0.25rem' }}>Inquiry received — ref: <span style={{ color: 'var(--gold)' }}>{ref}</span></p>
                <p style={{ color: 'var(--muted)', fontSize: '0.875rem' }}>We'll be in touch within 24 hours.</p>
              </div>
            ) : (
              <div style={{ display: 'flex', flexDirection: 'column', gap: '1rem' }}>
                <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '1rem' }}>
                  <div className="form-group">
                    <label className="form-label">Name *</label>
                    <input className="form-input" value={form.name} onChange={e => setForm({...form, name: e.target.value})} placeholder="Your name" />
                  </div>
                  <div className="form-group">
                    <label className="form-label">Phone *</label>
                    <input className="form-input" value={form.phone} onChange={e => setForm({...form, phone: e.target.value})} placeholder="03XX XXXXXXX" />
                  </div>
                </div>
                <div className="form-group">
                  <label className="form-label">What do you need printed?  *</label>
                  <textarea className="form-textarea" value={form.details} onChange={e => setForm({...form, details: e.target.value})}
                    placeholder="Describe your requirement — what, how many, size, finish, timeline..." style={{ minHeight: '100px' }} />
                </div>
                {status === 'error' && <p style={{ color: 'var(--error)', fontSize: '0.875rem' }}>Failed to send. Please WhatsApp us directly.</p>}
                <button onClick={handleSubmit} disabled={status === 'loading' || !form.name || !form.phone || !form.details}
                  className="btn btn-dark" style={{ alignSelf: 'flex-start' }}>
                  {status === 'loading' ? 'Sending...' : 'Send Inquiry →'}
                </button>
              </div>
            )}
          </div>
        </div>
      </section>
    </div>
  );
}

import type { Metadata } from 'next';
import './globals.css';
import Navbar from '@/components/layout/Navbar';
import Footer from '@/components/layout/Footer';

export const metadata: Metadata = {
  title: 'FS Prints — Stationery & Spiral Notebooks | Karachi',
  description: 'Quality stationery, custom spiral notebooks, and printing services in Karachi. Bulk corporate orders welcome.',
  keywords: 'stationery Karachi, spiral notebooks, bulk notebooks, printing services, CAIE workbooks',
};

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="en">
      <body>
        <Navbar />
        <main>{children}</main>
        <Footer />
      </body>
    </html>
  );
}

'use client';
import Link from 'next/link';

const sections = [
  {
    href: '/shop',
    tag: 'Retail Store',
    title: 'Stationery & Printed Materials',
    desc: 'Notebooks, pens, CAIE workbooks, visiting cards, and flyers — ordered online, delivered in Karachi.',
    cta: 'Browse Products',
    bg: 'var(--ivory)',
    accent: 'var(--gold)',
    icon: '🛍️',
  },
  {
    href: '/bulk',
    tag: 'Bulk & Corporate',
    title: 'Spiral Notebooks for Your Business',
    desc: 'Custom-manufactured spiral notebooks, branded stationery supply contracts, and bulk printing for corporates.',
    cta: 'Get a Quote',
    bg: 'var(--ink)',
    accent: 'var(--gold)',
    color: 'white',
    icon: '🏢',
  },
  {
    href: '/services',
    tag: 'Print Services',
    title: 'Events, Exhibitions & More',
    desc: 'From event signage to exhibition banners — professional print production with fast turnaround in Karachi.',
    cta: 'View Services',
    bg: '#1A2E42',
    accent: 'var(--gold)',
    color: 'white',
    icon: '🖨️',
  },
  {
    href: '/about',
    tag: 'Our Story',
    title: 'Built from Scratch in Karachi',
    desc: 'A founder-run stationery shop turned manufacturer. No shortcuts, no SaaS bills — just a proper business.',
    cta: 'Read Our Story',
    bg: 'var(--ivory)',
    accent: 'var(--ink)',
    icon: '📖',
  },
];

export default function HomePage() {
  return (
    <>
      {/* ---- Hero ---- */}
      <section style={{ background: 'var(--ink)', padding: '6rem 0 5rem', position: 'relative', overflow: 'hidden' }}>
        {/* Subtle grid background */}
        <div style={{
          position: 'absolute', inset: 0,
          backgroundImage: 'linear-gradient(rgba(232,160,32,0.04) 1px, transparent 1px), linear-gradient(90deg, rgba(232,160,32,0.04) 1px, transparent 1px)',
          backgroundSize: '40px 40px',
        }} />
        <div className="container" style={{ position: 'relative' }}>
          <div style={{ maxWidth: '680px' }}>
            <span style={{
              display: 'inline-block', background: 'rgba(232,160,32,0.15)', color: 'var(--gold)',
              padding: '0.35rem 1rem', borderRadius: '99px', fontSize: '0.8rem',
              fontWeight: 600, letterSpacing: '0.08em', textTransform: 'uppercase', marginBottom: '1.5rem',
            }}>Karachi's Own Stationery Brand</span>

            <h1 className="display" style={{ color: 'var(--white)', marginBottom: '1.5rem' }}>
              Where every page<br />
              <span style={{ color: 'var(--gold)' }}>begins well.</span>
            </h1>

            <p style={{ color: 'rgba(255,255,255,0.7)', fontSize: '1.1rem', lineHeight: 1.8, marginBottom: '2.5rem', maxWidth: '520px' }}>
              Retail stationery, custom spiral notebooks, and print services — all under one roof in Karachi. Stocked live. Ordered online.
            </p>

            <div style={{ display: 'flex', gap: '1rem', flexWrap: 'wrap' }}>
              <Link href="/shop" className="btn btn-primary">Shop Now</Link>
              <Link href="/bulk" className="btn btn-outline">Bulk Inquiry</Link>
            </div>

            <div style={{ display: 'flex', gap: '2.5rem', marginTop: '3rem', flexWrap: 'wrap' }}>
              {[['318+', 'Products'], ['2023', 'Est.'], ['COD', 'Available']].map(([val, lbl]) => (
                <div key={lbl}>
                  <div style={{ fontFamily: 'var(--font-display)', fontSize: '1.75rem', color: 'var(--gold)', lineHeight: 1 }}>{val}</div>
                  <div style={{ color: 'rgba(255,255,255,0.5)', fontSize: '0.8rem', marginTop: '0.25rem', letterSpacing: '0.05em' }}>{lbl}</div>
                </div>
              ))}
            </div>
          </div>
        </div>

        {/* Page-turn divider */}
        <div className="page-turn" style={{ position: 'absolute', bottom: -1, left: 0, right: 0, height: '50px' }}>
          <svg viewBox="0 0 1200 50" preserveAspectRatio="none" style={{ width: '100%', height: '100%' }}>
            <path d="M0,50 L0,20 Q300,0 600,25 Q900,50 1200,15 L1200,50 Z" fill="var(--white)" />
          </svg>
        </div>
      </section>

      {/* ---- 4 Section Cards ---- */}
      <section className="section" style={{ background: 'var(--white)' }}>
        <div className="container">
          <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(280px, 1fr))', gap: '1.5rem' }}>
            {sections.map((s) => (
              <Link key={s.href} href={s.href} style={{ textDecoration: 'none' }}>
                <div style={{
                  background: s.bg,
                  borderRadius: 'var(--radius-lg)',
                  padding: '2.25rem',
                  height: '100%',
                  display: 'flex', flexDirection: 'column', gap: '1rem',
                  border: s.bg === 'var(--ivory)' ? '1px solid var(--border)' : 'none',
                  transition: 'transform 0.2s ease, box-shadow 0.2s ease',
                  cursor: 'pointer',
                }}
                  onMouseEnter={e => { (e.currentTarget as HTMLElement).style.transform = 'translateY(-4px)'; (e.currentTarget as HTMLElement).style.boxShadow = '0 12px 40px rgba(0,0,0,0.12)'; }}
                  onMouseLeave={e => { (e.currentTarget as HTMLElement).style.transform = 'none'; (e.currentTarget as HTMLElement).style.boxShadow = 'none'; }}
                >
                  <div style={{ fontSize: '2rem' }}>{s.icon}</div>
                  <span style={{ fontSize: '0.75rem', fontWeight: 600, letterSpacing: '0.1em', textTransform: 'uppercase', color: s.accent }}>{s.tag}</span>
                  <h3 className="display" style={{ color: s.color === 'white' ? 'var(--white)' : 'var(--ink)', fontSize: '1.3rem', lineHeight: 1.3 }}>{s.title}</h3>
                  <p style={{ color: s.color === 'white' ? 'rgba(255,255,255,0.7)' : 'var(--muted)', fontSize: '0.9rem', lineHeight: 1.7, flex: 1 }}>{s.desc}</p>
                  <span style={{ color: s.accent, fontWeight: 600, fontSize: '0.875rem', display: 'flex', alignItems: 'center', gap: '0.3rem' }}>
                    {s.cta} →
                  </span>
                </div>
              </Link>
            ))}
          </div>
        </div>
      </section>

      {/* ---- Trust bar ---- */}
      <section style={{ background: 'var(--ivory)', borderTop: '1px solid var(--border)', padding: '2rem 0' }}>
        <div className="container">
          <div style={{ display: 'flex', justifyContent: 'center', gap: '3rem', flexWrap: 'wrap', alignItems: 'center' }}>
            {['✅ Cash on Delivery', '🚚 Karachi Delivery', '🏭 In-house Manufacturing', '📦 Bulk Orders Welcome', '💬 WhatsApp Support'].map(t => (
              <span key={t} style={{ fontSize: '0.875rem', fontWeight: 500, color: 'var(--ink)' }}>{t}</span>
            ))}
          </div>
        </div>
      </section>
    </>
  );
}

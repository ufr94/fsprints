'use client';
import { useState, useEffect, useCallback } from 'react';
import { getProducts, getCategories, placeOrder } from '@/lib/api';

interface Product {
  id: number; sku: string; name: string; price: number;
  stock: number; unit: string; category: string; stock_status: string;
}

interface CartItem extends Product { quantity: number; }

export default function ShopPage() {
  const [products, setProducts]     = useState<Product[]>([]);
  const [categories, setCategories] = useState<{id:number;name:string;product_count:number}[]>([]);
  const [loading, setLoading]       = useState(true);
  const [search, setSearch]         = useState('');
  const [category, setCategory]     = useState('');
  const [inStock, setInStock]       = useState(false);
  const [page, setPage]             = useState(1);
  const [meta, setMeta]             = useState<any>(null);
  const [cart, setCart]             = useState<CartItem[]>([]);
  const [cartOpen, setCartOpen]     = useState(false);
  const [checkoutOpen, setCheckoutOpen] = useState(false);
  const [orderStatus, setOrderStatus]   = useState<'idle'|'loading'|'success'|'error'>('idle');
  const [orderRef, setOrderRef]         = useState('');
  const [form, setForm]                 = useState({ name:'', phone:'', email:'', address:'', payment:'cod', notes:'' });

  const fetchProducts = useCallback(async () => {
    setLoading(true);
    try {
      const res = await getProducts({ category, search, in_stock: inStock, page });
      setProducts(res.data);
      setMeta(res.meta);
    } catch { setProducts([]); }
    setLoading(false);
  }, [category, search, inStock, page]);

  useEffect(() => { fetchProducts(); }, [fetchProducts]);
  useEffect(() => {
    getCategories().then(r => setCategories(r.data)).catch(() => {});
  }, []);

  const addToCart = (p: Product) => {
    setCart(prev => {
      const existing = prev.find(i => i.id === p.id);
      if (existing) return prev.map(i => i.id === p.id ? {...i, quantity: i.quantity+1} : i);
      return [...prev, {...p, quantity: 1}];
    });
  };
  const updateQty = (id: number, delta: number) => {
    setCart(prev => prev.map(i => i.id === id ? {...i, quantity: Math.max(1, i.quantity+delta)} : i).filter(i => i.quantity > 0));
  };
  const removeItem = (id: number) => setCart(prev => prev.filter(i => i.id !== id));
  const cartTotal = cart.reduce((s, i) => s + i.price * i.quantity, 0);
  const cartCount = cart.reduce((s, i) => s + i.quantity, 0);

  const handleCheckout = async () => {
    if (!form.name || !form.phone) return;
    setOrderStatus('loading');
    try {
      // placeOrder already imported
      const res = await placeOrder({
        customer: { name: form.name, phone: form.phone, email: form.email, address: form.address },
        items: cart.map(i => ({ product_id: i.id, product_name: i.name, quantity: i.quantity, unit_price: i.price })),
        payment_method: form.payment,
        order_notes: form.notes,
        order_source: 'retail',
      });
      setOrderRef(res.data.invoice_no);
      setOrderStatus('success');
      setCart([]);
    } catch { setOrderStatus('error'); }
  };

  const stockBadge = (s: string) => {
    if (s === 'out_of_stock') return <span className="badge badge-red">Out of Stock</span>;
    if (s === 'low_stock')    return <span className="badge badge-gold">Low Stock</span>;
    return <span className="badge badge-green">In Stock</span>;
  };

  return (
    <div style={{ background: 'var(--white)', minHeight: '100vh' }}>
      {/* Header */}
      <div style={{ background: 'var(--ivory)', borderBottom: '1px solid var(--border)', padding: '2.5rem 0' }}>
        <div className="container" style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', flexWrap: 'wrap', gap: '1rem' }}>
          <div>
            <span style={{ fontSize: '0.75rem', fontWeight: 600, letterSpacing: '0.1em', textTransform: 'uppercase', color: 'var(--gold)' }}>Retail Store</span>
            <h1 className="display" style={{ fontSize: '2rem', marginTop: '0.25rem' }}>Stationery & Printed Materials</h1>
          </div>
          <button onClick={() => setCartOpen(true)} className="btn btn-dark" style={{ position: 'relative' }}>
            🛒 Cart
            {cartCount > 0 && <span style={{
              position: 'absolute', top: '-8px', right: '-8px',
              background: 'var(--gold)', color: 'var(--ink)', borderRadius: '99px',
              width: '20px', height: '20px', display: 'flex', alignItems: 'center', justifyContent: 'center',
              fontSize: '0.7rem', fontWeight: 700,
            }}>{cartCount}</span>}
          </button>
        </div>
      </div>

      <div className="container" style={{ padding: '2rem 1.5rem' }}>
        {/* Filters */}
        <div style={{ display: 'flex', gap: '1rem', marginBottom: '2rem', flexWrap: 'wrap', alignItems: 'center' }}>
          <input className="form-input" placeholder="Search products..." value={search}
            onChange={e => { setSearch(e.target.value); setPage(1); }}
            style={{ maxWidth: '280px' }} />
          <select className="form-select" value={category} onChange={e => { setCategory(e.target.value); setPage(1); }}
            style={{ maxWidth: '200px' }}>
            <option value="">All Categories</option>
            {categories.map(c => <option key={c.id} value={c.name}>{c.name} ({c.product_count})</option>)}
          </select>
          <label style={{ display: 'flex', alignItems: 'center', gap: '0.5rem', fontSize: '0.875rem', cursor: 'pointer' }}>
            <input type="checkbox" checked={inStock} onChange={e => { setInStock(e.target.checked); setPage(1); }} />
            In stock only
          </label>
          {meta && <span style={{ marginLeft: 'auto', color: 'var(--muted)', fontSize: '0.875rem' }}>{meta.total} products</span>}
        </div>

        {/* Grid */}
        {loading ? (
          <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fill, minmax(220px, 1fr))', gap: '1.25rem' }}>
            {Array(8).fill(0).map((_, i) => (
              <div key={i} style={{ height: '240px', background: 'var(--ivory)', borderRadius: 'var(--radius-lg)', animation: 'pulse 1.5s infinite' }} />
            ))}
          </div>
        ) : products.length === 0 ? (
          <div style={{ textAlign: 'center', padding: '5rem 0', color: 'var(--muted)' }}>
            <div style={{ fontSize: '3rem', marginBottom: '1rem' }}>📦</div>
            <p>No products found. Try a different search or category.</p>
          </div>
        ) : (
          <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fill, minmax(220px, 1fr))', gap: '1.25rem' }}>
            {products.map(p => (
              <div key={p.id} className="card">
                <div style={{ background: 'var(--ivory)', height: '140px', display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: '3rem' }}>
                  {p.category?.toLowerCase().includes('notebook') ? '📒' : p.category?.toLowerCase().includes('pen') ? '🖊️' : '📄'}
                </div>
                <div style={{ padding: '1rem' }}>
                  <div style={{ marginBottom: '0.4rem' }}>{stockBadge(p.stock_status)}</div>
                  <div style={{ fontSize: '0.75rem', color: 'var(--muted)', marginBottom: '0.25rem' }}>{p.sku}</div>
                  <h3 style={{ fontSize: '0.9rem', fontWeight: 600, marginBottom: '0.5rem', lineHeight: 1.4 }}>{p.name}</h3>
                  <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
                    <span style={{ fontFamily: 'var(--font-display)', fontSize: '1.1rem', fontWeight: 700 }}>Rs. {p.price.toLocaleString()}</span>
                    <button onClick={() => addToCart(p)} disabled={p.stock_status === 'out_of_stock'}
                      className="btn btn-primary" style={{ padding: '0.4rem 0.9rem', fontSize: '0.8rem' }}>
                      Add
                    </button>
                  </div>
                </div>
              </div>
            ))}
          </div>
        )}

        {/* Pagination */}
        {meta && meta.total_pages > 1 && (
          <div style={{ display: 'flex', justifyContent: 'center', gap: '0.5rem', marginTop: '2.5rem' }}>
            {Array.from({ length: meta.total_pages }, (_, i) => i + 1).map(p => (
              <button key={p} onClick={() => setPage(p)} className="btn"
                style={{ padding: '0.5rem 0.9rem', background: page === p ? 'var(--gold)' : 'var(--ivory)', color: 'var(--ink)', border: '1px solid var(--border)' }}>
                {p}
              </button>
            ))}
          </div>
        )}
      </div>

      {/* Cart Sidebar */}
      {cartOpen && (
        <div style={{ position: 'fixed', inset: 0, zIndex: 200 }}>
          <div onClick={() => setCartOpen(false)} style={{ position: 'absolute', inset: 0, background: 'rgba(0,0,0,0.4)' }} />
          <div style={{ position: 'absolute', right: 0, top: 0, bottom: 0, width: 'min(420px, 100vw)', background: 'var(--white)', display: 'flex', flexDirection: 'column', boxShadow: '-4px 0 20px rgba(0,0,0,0.15)' }}>
            <div style={{ padding: '1.5rem', borderBottom: '1px solid var(--border)', display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
              <h3 style={{ fontFamily: 'var(--font-display)' }}>Your Cart ({cartCount})</h3>
              <button onClick={() => setCartOpen(false)} style={{ background: 'none', border: 'none', fontSize: '1.5rem', color: 'var(--muted)' }}>×</button>
            </div>
            <div style={{ flex: 1, overflowY: 'auto', padding: '1rem 1.5rem' }}>
              {cart.length === 0 ? (
                <p style={{ color: 'var(--muted)', textAlign: 'center', marginTop: '2rem' }}>Your cart is empty</p>
              ) : cart.map(item => (
                <div key={item.id} style={{ display: 'flex', gap: '1rem', alignItems: 'center', padding: '1rem 0', borderBottom: '1px solid var(--border)' }}>
                  <div style={{ flex: 1 }}>
                    <div style={{ fontWeight: 500, fontSize: '0.9rem', lineHeight: 1.4 }}>{item.name}</div>
                    <div style={{ color: 'var(--muted)', fontSize: '0.8rem' }}>Rs. {item.price.toLocaleString()} each</div>
                  </div>
                  <div style={{ display: 'flex', alignItems: 'center', gap: '0.5rem' }}>
                    <button onClick={() => updateQty(item.id, -1)} style={{ width: '28px', height: '28px', border: '1px solid var(--border)', borderRadius: 'var(--radius)', background: 'none', fontWeight: 700 }}>−</button>
                    <span style={{ fontWeight: 600, minWidth: '20px', textAlign: 'center' }}>{item.quantity}</span>
                    <button onClick={() => updateQty(item.id, 1)} style={{ width: '28px', height: '28px', border: '1px solid var(--border)', borderRadius: 'var(--radius)', background: 'none', fontWeight: 700 }}>+</button>
                    <button onClick={() => removeItem(item.id)} style={{ background: 'none', border: 'none', color: 'var(--error)', fontSize: '1.1rem', marginLeft: '0.25rem' }}>×</button>
                  </div>
                </div>
              ))}
            </div>
            {cart.length > 0 && (
              <div style={{ padding: '1.5rem', borderTop: '1px solid var(--border)' }}>
                <div style={{ display: 'flex', justifyContent: 'space-between', fontWeight: 700, fontSize: '1.1rem', marginBottom: '1rem' }}>
                  <span>Total</span>
                  <span>Rs. {cartTotal.toLocaleString()}</span>
                </div>
                <button onClick={() => { setCartOpen(false); setCheckoutOpen(true); }} className="btn btn-primary" style={{ width: '100%', justifyContent: 'center' }}>
                  Proceed to Checkout
                </button>
              </div>
            )}
          </div>
        </div>
      )}

      {/* Checkout Modal */}
      {checkoutOpen && (
        <div style={{ position: 'fixed', inset: 0, zIndex: 300, display: 'flex', alignItems: 'center', justifyContent: 'center', padding: '1rem' }}>
          <div onClick={() => { if (orderStatus !== 'loading') setCheckoutOpen(false); }} style={{ position: 'absolute', inset: 0, background: 'rgba(0,0,0,0.5)' }} />
          <div style={{ position: 'relative', background: 'var(--white)', borderRadius: 'var(--radius-lg)', padding: '2rem', width: '100%', maxWidth: '480px', maxHeight: '90vh', overflowY: 'auto' }}>
            {orderStatus === 'success' ? (
              <div style={{ textAlign: 'center', padding: '1rem 0' }}>
                <div style={{ fontSize: '3rem', marginBottom: '1rem' }}>✅</div>
                <h2 className="display" style={{ marginBottom: '0.75rem' }}>Order Confirmed!</h2>
                <p style={{ color: 'var(--muted)', marginBottom: '0.5rem' }}>Your order reference is:</p>
                <div style={{ fontFamily: 'var(--font-display)', fontSize: '1.4rem', color: 'var(--gold)', marginBottom: '1.5rem' }}>{orderRef}</div>
                <p style={{ color: 'var(--muted)', fontSize: '0.875rem', marginBottom: '2rem' }}>We'll contact you on WhatsApp to confirm delivery details.</p>
                <button onClick={() => { setCheckoutOpen(false); setOrderStatus('idle'); }} className="btn btn-primary" style={{ width: '100%', justifyContent: 'center' }}>Done</button>
              </div>
            ) : (
              <>
                <h2 className="display" style={{ marginBottom: '1.5rem' }}>Checkout</h2>
                <div style={{ display: 'flex', flexDirection: 'column', gap: '1rem' }}>
                  <div className="form-group">
                    <label className="form-label">Full Name *</label>
                    <input className="form-input" value={form.name} onChange={e => setForm({...form, name: e.target.value})} placeholder="Ahmed Khan" />
                  </div>
                  <div className="form-group">
                    <label className="form-label">Phone *</label>
                    <input className="form-input" value={form.phone} onChange={e => setForm({...form, phone: e.target.value})} placeholder="03XX XXXXXXX" />
                  </div>
                  <div className="form-group">
                    <label className="form-label">Email</label>
                    <input className="form-input" type="email" value={form.email} onChange={e => setForm({...form, email: e.target.value})} placeholder="optional" />
                  </div>
                  <div className="form-group">
                    <label className="form-label">Delivery Address</label>
                    <input className="form-input" value={form.address} onChange={e => setForm({...form, address: e.target.value})} placeholder="House/flat, Block, Area, Karachi" />
                  </div>
                  <div className="form-group">
                    <label className="form-label">Payment Method</label>
                    <select className="form-select" value={form.payment} onChange={e => setForm({...form, payment: e.target.value})}>
                      <option value="cod">Cash on Delivery</option>
                      <option value="bank_transfer">Bank Transfer</option>
                    </select>
                  </div>
                  <div className="form-group">
                    <label className="form-label">Order Notes</label>
                    <textarea className="form-textarea" value={form.notes} onChange={e => setForm({...form, notes: e.target.value})} placeholder="Any special instructions..." style={{ minHeight: '80px' }} />
                  </div>
                  <div style={{ background: 'var(--ivory)', borderRadius: 'var(--radius)', padding: '1rem', marginTop: '0.5rem' }}>
                    <div style={{ fontWeight: 600, marginBottom: '0.5rem' }}>Order Summary</div>
                    {cart.map(i => (
                      <div key={i.id} style={{ display: 'flex', justifyContent: 'space-between', fontSize: '0.875rem', marginBottom: '0.25rem' }}>
                        <span>{i.name} × {i.quantity}</span>
                        <span>Rs. {(i.price * i.quantity).toLocaleString()}</span>
                      </div>
                    ))}
                    <div style={{ borderTop: '1px solid var(--border)', paddingTop: '0.5rem', marginTop: '0.5rem', fontWeight: 700, display: 'flex', justifyContent: 'space-between' }}>
                      <span>Total</span><span>Rs. {cartTotal.toLocaleString()}</span>
                    </div>
                  </div>
                  {orderStatus === 'error' && <p style={{ color: 'var(--error)', fontSize: '0.875rem' }}>Something went wrong. Please try again or WhatsApp us.</p>}
                  <div style={{ display: 'flex', gap: '0.75rem', marginTop: '0.5rem' }}>
                    <button onClick={() => setCheckoutOpen(false)} className="btn" style={{ flex: 1, background: 'var(--ivory)', border: '1px solid var(--border)', justifyContent: 'center' }}>Cancel</button>
                    <button onClick={handleCheckout} disabled={orderStatus === 'loading' || !form.name || !form.phone}
                      className="btn btn-primary" style={{ flex: 1, justifyContent: 'center' }}>
                      {orderStatus === 'loading' ? 'Placing...' : 'Place Order'}
                    </button>
                  </div>
                </div>
              </>
            )}
          </div>
        </div>
      )}

      <style>{`@keyframes pulse { 0%,100%{opacity:1} 50%{opacity:0.5} }`}</style>
    </div>
  );
}

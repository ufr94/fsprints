// ============================================================
// FS Prints — API Client
// ============================================================

const API_BASE = process.env.NEXT_PUBLIC_API_BASE;
const API_KEY  = process.env.NEXT_PUBLIC_API_KEY;

const defaultHeaders = {
  'Content-Type': 'application/json',
  'X-API-Key': API_KEY ?? '',
};

export interface ProductsParams {
  category?: string;
  search?: string;
  in_stock?: boolean;
  page?: number;
}

export async function getProducts(params: ProductsParams = {}) {
  const { category, search, in_stock, page = 1 } = params;
  const q = new URLSearchParams({ page: String(page) });
  if (category) q.set('category', category);
  if (search)   q.set('search', search);
  if (in_stock) q.set('in_stock', '1');
  const res = await fetch(`${API_BASE}/products.php?${q}`, { headers: defaultHeaders });
  if (!res.ok) throw new Error('Failed to fetch products');
  return res.json();
}

export async function getCategories() {
  const res = await fetch(`${API_BASE}/categories.php`, { headers: defaultHeaders });
  if (!res.ok) throw new Error('Failed to fetch categories');
  return res.json();
}

export async function checkStock(ids: number[]) {
  const res = await fetch(`${API_BASE}/stock.php?ids=${ids.join(',')}`, { headers: defaultHeaders });
  if (!res.ok) throw new Error('Failed to check stock');
  return res.json();
}

export interface OrderItem {
  product_id?: number;
  product_name: string;
  quantity: number;
  unit_price: number;
}

export interface OrderData {
  customer: { name: string; phone: string; email?: string; address?: string; };
  items: OrderItem[];
  payment_method: string;
  order_notes?: string;
  order_source?: string;
}

export async function placeOrder(orderData: OrderData) {
  const res = await fetch(`${API_BASE}/orders.php`, {
    method: 'POST',
    headers: defaultHeaders,
    body: JSON.stringify(orderData),
  });
  const data = await res.json();
  if (!data.success) throw new Error(data.error || 'Order failed');
  return data;
}

export interface QuoteData {
  type: string;
  name: string;
  contact_person?: string;
  phone: string;
  email?: string;
  city?: string;
  details: string;
  quantity?: number;
  timeline?: string;
}

export async function submitQuote(quoteData: QuoteData) {
  const res = await fetch(`${API_BASE}/quote.php`, {
    method: 'POST',
    headers: defaultHeaders,
    body: JSON.stringify(quoteData),
  });
  const data = await res.json();
  if (!data.success) throw new Error(data.error || 'Submission failed');
  return data;
}
